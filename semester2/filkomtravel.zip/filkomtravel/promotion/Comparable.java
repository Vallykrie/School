public interface Comparable {

}
