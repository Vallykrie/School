package filkomtravel.studikasus1;

public class Motor extends Vehicle{
    final String type = "Motor";

    Motor(String model, String color, String numberPlate, int capacity, double price) {
        super(model, color, numberPlate, capacity, price);
    }

}
