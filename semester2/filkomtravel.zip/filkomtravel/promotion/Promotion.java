import java.util.Date;

public abstract class Promotion implements Applicable, Comparable {
    private String promoCode;
    private Date startDate, endDate;

}
