package filkomtravel.studikasus1;

public class Mobil extends Vehicle {
    final String type = "Mobil";

    Mobil(String model, String color, String numberPlate, int capacity, double price) {
        super(model, color, numberPlate, capacity, price);
    }

}
