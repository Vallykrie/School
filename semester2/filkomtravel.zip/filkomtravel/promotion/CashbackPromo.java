public class CashbackPromo {

}
